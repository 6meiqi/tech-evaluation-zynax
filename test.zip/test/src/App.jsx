import React, { useState } from 'react';
import {
  Search,
  Briefcase,
  Gift,
  Bell,
  Sparkles,
  Zap,
  Plus,
  Home,
  Users,
  Eye,
  Grid,
  User,
  SlidersHorizontal,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  MessageSquare,
  MoreHorizontal,
  Bookmark,
  Share2,
  Lock,
  X,
  Compass,
  Flame,
  CheckCircle2,
  ExternalLink,
  Command,
  Sliders,
  HelpCircle
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('For you');
  const [activeSidebar, setActiveSidebar] = useState('home');
  const [upvotes, setUpvotes] = useState(73);
  const [hasUpvoted, setHasUpvoted] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  const tags = ['Want chips 🍟 ?', 'For you', 'Web Development', 'PHP', 'GitHub', 'React', 'AI', 'TailwindCSS'];

  const happeningItems = [
    {
      id: 1,
      title: 'Moonshot AI prepares to release Kimi K3, a 3-trillion-parameter open frontier model',
      time: '8m ago',
      source: 'TechCrunch'
    },
    {
      id: 2,
      title: "Nvidia discusses $250B guarantee to backstop OpenAI's 10GW Ohio data center",
      time: '2h ago',
      source: 'Bloomberg'
    },
    {
      id: 3,
      title: 'Cursor zero-day lets malicious git.exe hijack Windows developers on project open',
      time: '13h ago',
      source: 'BleepingComputer'
    },
    {
      id: 4,
      title: 'WordPress patches pre-auth RCE requiring no plugins and activates forced auto-updates',
      time: '1d ago',
      source: 'The Hacker News'
    }
  ];

  const handleUpvote = () => {
    if (hasUpvoted) {
      setUpvotes(upvotes - 1);
      setHasUpvoted(false);
    } else {
      setUpvotes(upvotes + 1);
      setHasUpvoted(true);
    }
  };

  const handleFeedbackSubmit = (e) => {
    e.preventDefault();
    if (!feedbackText.trim()) return;
    setFeedbackSubmitted(true);
    setTimeout(() => {
      setShowFeedbackModal(false);
      setFeedbackSubmitted(false);
      setFeedbackText('');
    }, 1800);
  };

  return (
    <div className="bg-[#0b0e14] text-slate-200 min-h-screen flex flex-col font-sans selection:bg-purple-500 selection:text-white antialiased">
      {/* 1. TOP HEADER / NAVIGATION BAR */}
      <header class="sticky top-0 z-40 bg-[#0b0e14]/90 backdrop-blur-md border-b border-slate-800/60 px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Left Section: Logo & Search */}
        <div className="flex items-center gap-6 flex-1 max-w-xl">
          {/* Logo */}
          <a href="#" className="flex items-center gap-1.5 text-xl font-black tracking-tight text-white hover:opacity-90 transition group">
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 bg-clip-text text-transparent">
              daily.dev
            </span>
          </a>

          {/* Search Bar */}
          <div className="relative w-full max-w-md hidden sm:block">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search posts, tags, or sources..."
              className="w-full bg-[#161b26] border border-slate-800/80 text-sm text-slate-200 placeholder-slate-400 rounded-xl pl-9 pr-20 py-2 focus:outline-none focus:border-purple-500/60 focus:ring-1 focus:ring-purple-500/50 transition shadow-inner"
            />
            <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 text-[10px] font-semibold text-slate-400 bg-slate-800/80 border border-slate-700/60 rounded flex items-center gap-0.5">
                <Command className="w-2.5 h-2.5" /> K
              </kbd>
            </div>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2.5 md:gap-3">
          <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition relative hidden md:block" title="Work Opportunities">
            <Briefcase className="w-5 h-5" />
          </button>

          <div className="relative flex items-center">
            <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition" title="Rewards">
              <Gift className="w-5 h-5" />
            </button>
            <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-[10px] font-black rounded-full border-2 border-[#0b0e14]">
              8
            </span>
          </div>

          <div className="relative flex items-center">
            <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition" title="Notifications">
              <Bell className="w-5 h-5" />
            </button>
            <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#0b0e14]"></span>
          </div>

          {/* Points & Streaks Badges */}
          <div className="hidden sm:flex items-center gap-2 bg-[#161b26] px-3 py-1.5 rounded-xl border border-slate-800/80 text-xs font-bold shadow-inner">
            <span className="flex items-center gap-1 text-amber-400 hover:scale-105 transition cursor-pointer" title="Reputation Points">
              <Sparkles className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> 1.1K
            </span>
            <span className="w-px h-3.5 bg-slate-800"></span>
            <span className="flex items-center gap-1 text-purple-400 hover:scale-105 transition cursor-pointer" title="Daily Streak">
              <Zap className="w-3.5 h-3.5 fill-purple-400 text-purple-400" /> 510
            </span>
          </div>

          {/* User Profile Avatar Image */}
          <button className="ml-1 relative focus:outline-none ring-2 ring-purple-500/60 hover:ring-purple-400 rounded-full transition transform active:scale-95 shadow-lg shadow-purple-900/20">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
              alt="User Profile"
              className="w-8 h-8 rounded-full object-cover"
            />
          </button>
        </div>
      </header>

      {/* MAIN APP CONTAINER WITH LEFT SIDEBAR */}
      <div className="flex flex-1">
        {/* 4. LEFT SIDEBAR NAVIGATION BAR */}
        <aside className="w-14 border-r border-slate-800/60 bg-[#0b0e14] flex flex-col items-center py-4 gap-4 shrink-0 sticky top-[57px] h-[calc(100vh-57px)]">
          <button className="p-2.5 text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl hover:opacity-90 shadow-lg shadow-purple-900/30 transition transform hover:scale-105 active:scale-95" title="New Post">
            <Plus className="w-5 h-5" />
          </button>

          <nav className="flex flex-col gap-2 w-full px-2 mt-2">
            {[
              { id: 'home', icon: Home, label: 'Home' },
              { id: 'community', icon: Users, label: 'Community' },
              { id: 'explore', icon: Eye, label: 'Explore' },
              { id: 'popular', icon: Sparkles, label: 'Popular' },
              { id: 'custom', icon: Grid, label: 'Custom Grid' }
            ].map((item) => {
              const IconComponent = item.icon;
              const isActive = activeSidebar === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSidebar(item.id)}
                  className={`p-2.5 rounded-xl flex items-center justify-center transition relative ${
                    isActive
                      ? 'text-white bg-slate-800/80 border border-slate-700/60 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                  }`}
                  title={item.label}
                >
                  <IconComponent className="w-5 h-5" />
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-purple-500 rounded-r-full"></span>
                  )}
                </button>
              );
            })}
          </nav>

          <div className="mt-auto">
            <button
              onClick={() => setActiveSidebar('profile')}
              className={`p-2.5 rounded-xl flex items-center justify-center transition ${
                activeSidebar === 'profile'
                  ? 'text-white bg-slate-800 border border-slate-700/60'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
              title="Account Settings"
            >
              <User className="w-5 h-5" />
            </button>
          </div>
        </aside>

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 p-4 md:p-6 max-w-7xl mx-auto w-full overflow-x-hidden">
          {/* 2. SECONDARY NAVIGATION / TAGS BAR */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            {/* Left Filter Tags */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full scrollbar-none">
              {tags.map((tag) => {
                const isActive = activeTab === tag;
                const isSpecial = tag.includes('chips');
                return (
                  <button
                    key={tag}
                    onClick={() => setActiveTab(tag)}
                    className={`font-semibold text-xs px-3.5 py-2 rounded-xl whitespace-nowrap transition transform active:scale-95 ${
                      isSpecial
                        ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-lg shadow-purple-900/30'
                        : isActive
                        ? 'bg-[#1e2638] text-white border border-purple-500/50 shadow-md'
                        : 'bg-[#161b26] hover:bg-slate-800 border border-slate-800 text-slate-300'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>

            {/* Right Action Pill Buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <button className="bg-[#161b26] hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium px-3 py-2 rounded-xl flex items-center gap-1.5 transition active:scale-95">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline">Feed settings</span>
              </button>

              <button className="bg-[#161b26] hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium px-3 py-2 rounded-xl flex items-center gap-1 transition active:scale-95">
                + Shortcuts
              </button>

              <button className="bg-[#161b26] border border-slate-800 text-slate-300 text-xs font-semibold px-2.5 py-2 rounded-xl flex items-center gap-1 hover:border-slate-700 transition">
                <Sparkles className="w-3.5 h-3.5 text-purple-400 fill-purple-400" /> 4/5
              </button>
            </div>
          </div>

          {/* 3. MAIN CONTENT GRID */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* LEFT COLUMN: HAPPENING NOW CARD (5 Cols) */}
            <div className="lg:col-span-5 bg-[#121620] border border-slate-800/80 rounded-2xl p-5 flex flex-col justify-between shadow-xl relative overflow-hidden group hover:border-slate-700/80 transition duration-300">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl pointer-events-none rounded-full"></div>
              
              <div>
                {/* Header Title */}
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800/60">
                  <h2 className="text-xl font-black flex items-center gap-1.5 tracking-tight">
                    <span className="text-emerald-400">Happening</span>
                    <span className="text-lime-400">Now</span>
                  </h2>
                  <span className="flex h-2 w-2 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                </div>

                {/* Article List */}
                <div className="space-y-4">
                  {happeningItems.map((item, index) => (
                    <div
                      key={item.id}
                      className={`group/item cursor-pointer transition ${
                        index !== happeningItems.length - 1 ? 'border-b border-slate-800/60 pb-3.5' : ''
                      }`}
                    >
                      <h3 className="text-sm font-bold text-slate-100 group-hover/item:text-purple-400 transition leading-snug line-clamp-2">
                        {item.title}
                      </h3>
                      <div className="flex items-center justify-between mt-1.5 text-xs text-slate-500 font-medium">
                        <span>{item.source}</span>
                        <span>{item.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Read All Link */}
              <div className="mt-6 pt-3 border-t border-slate-800/60">
                <a
                  href="#"
                  className="text-xs font-bold text-emerald-400 hover:text-emerald-300 transition flex items-center gap-1 group/link w-fit"
                >
                  Read all happening updates
                  <ChevronRight className="w-3.5 h-3.5 transform group-hover/link:translate-x-1 transition" />
                </a>
              </div>
            </div>

            {/* RIGHT COLUMN: MAIN FEATURED POST CARD (7 Cols) */}
            <div className="lg:col-span-7 bg-[#121620] border border-slate-800/80 rounded-2xl p-5 md:p-6 flex flex-col justify-between shadow-xl relative overflow-hidden hover:border-slate-700/80 transition duration-300">
              <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/5 blur-3xl pointer-events-none rounded-full"></div>

              <div>
                {/* Author Badge */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 bg-orange-600 rounded-full flex items-center justify-center font-black text-white text-xs shadow-md ring-2 ring-orange-500/30">
                      Y
                    </div>
                    <span className="text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer">
                      Y Combinator News
                    </span>
                  </div>

                  <button
                    onClick={() => setIsBookmarked(!isBookmarked)}
                    className={`p-1.5 rounded-lg transition ${
                      isBookmarked ? 'text-purple-400 bg-purple-500/10' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                    title="Bookmark"
                  >
                    <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-purple-400' : ''}`} />
                  </button>
                </div>

                {/* Post Title */}
                <h1 className="text-xl md:text-2xl font-extrabold text-white mb-3 hover:text-purple-400 cursor-pointer leading-tight transition">
                  So Reddit has decided that plain HTML is unsafe
                </h1>

                {/* Tags */}
                <div className="flex flex-wrap items-center gap-1.5 mb-3">
                  {['#javascript', '#html', '#crawling'].map((tag) => (
                    <span
                      key={tag}
                      className="bg-slate-800/80 hover:bg-slate-700/80 text-slate-400 hover:text-slate-200 text-xs px-2.5 py-1 rounded-md border border-slate-700/50 cursor-pointer transition"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Timestamp / Read Time */}
                <p className="text-xs text-slate-500 mb-5 font-medium">Jul 22 · 9m read time</p>

                {/* EMBEDDED LOGIN PREVIEW CONTAINER */}
                <div className="bg-[#090b0e] border border-slate-800/80 rounded-2xl p-5 md:p-6 mb-5 flex flex-col items-center justify-center max-w-lg mx-auto shadow-2xl relative">
                  <div className="w-full space-y-3">
                    {/* Google Button */}
                    <button className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs py-2.5 px-4 rounded-full flex items-center justify-center gap-2.5 transition shadow-lg transform active:scale-98">
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                      Continue with Google
                    </button>

                    {/* Magic Link Button */}
                    <button className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs py-2.5 px-4 rounded-full flex items-center justify-center gap-1.5 transition shadow-lg transform active:scale-98">
                      <ExternalLink className="w-3.5 h-3.5 text-slate-700" />
                      Email me a one-time link
                    </button>

                    {/* Divider OR */}
                    <div className="relative my-4 flex items-center justify-center">
                      <div className="border-t border-slate-800 w-full"></div>
                      <span className="bg-[#090b0e] px-3 text-[10px] tracking-wider uppercase font-extrabold text-slate-500 absolute">
                        OR
                      </span>
                    </div>

                    {/* Disabled Input Field */}
                    <div>
                      <input
                        type="text"
                        placeholder="Email or username *"
                        disabled
                        className="w-full bg-[#161b26] border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-400 placeholder-slate-500 cursor-not-allowed focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Post Footer Action Controls */}
              <div className="flex items-center justify-between border-t border-slate-800/60 pt-3.5 text-xs text-slate-400">
                <div class="flex items-center gap-4">
                  {/* Upvote/Downvote Pill */}
                  <div className="flex items-center bg-[#161b26] border border-slate-800 rounded-xl p-1 gap-1">
                    <button
                      onClick={handleUpvote}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded-lg transition ${
                        hasUpvoted
                          ? 'text-purple-400 bg-purple-500/10 font-black'
                          : 'hover:text-purple-400 hover:bg-slate-800 text-slate-300'
                      }`}
                      title="Upvote"
                    >
                      <ArrowUp className={`w-4 h-4 ${hasUpvoted ? 'stroke-[3]' : ''}`} />
                      <span className="font-bold">{upvotes}</span>
                    </button>

                    <span className="w-px h-3.5 bg-slate-800"></span>

                    <button className="p-1 hover:text-purple-400 hover:bg-slate-800 rounded-lg transition" title="Downvote">
                      <ArrowDown className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Comments Counter */}
                  <button className="flex items-center gap-1.5 text-slate-400 hover:text-purple-400 transition bg-[#161b26] hover:bg-slate-800 border border-slate-800 px-3 py-1.5 rounded-xl">
                    <MessageSquare className="w-4 h-4" />
                    <span className="font-bold text-slate-200">12</span>
                  </button>

                  <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition hidden sm:block" title="Share">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>

                {/* More Options */}
                <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition" title="More Options">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* 5. BOTTOM RIGHT FLOATING FEEDBACK WIDGET */}
      <div className="fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setShowFeedbackModal(true)}
          className="bg-white text-slate-900 px-3.5 py-1.5 rounded-full shadow-2xl border border-slate-200 flex items-center gap-2.5 text-xs font-bold hover:bg-slate-100 transition transform hover:scale-105 active:scale-95 group"
        >
          <span>Feedback</span>
          <div className="flex -space-x-1.5 overflow-hidden">
            <img
              className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100"
              alt="Avatar 1"
            />
            <img
              className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100"
              alt="Avatar 2"
            />
            <img
              className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100"
              alt="Avatar 3"
            />
          </div>
        </button>
      </div>

      {/* FEEDBACK MODAL DIALOG */}
      {showFeedbackModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121620] border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl relative animate-in fade-in zoom-in duration-200">
            <button
              onClick={() => setShowFeedbackModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">Send us your feedback</h3>
            <p className="text-xs text-slate-400 mb-4">We'd love to hear how we can improve daily.dev for you!</p>

            {feedbackSubmitted ? (
              <div className="py-8 flex flex-col items-center justify-center text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 animate-bounce" />
                <p className="text-sm font-bold text-white">Thank you for your feedback!</p>
                <p className="text-xs text-slate-400">Our team reads every single message.</p>
              </div>
            ) : (
              <form onSubmit={handleFeedbackSubmit} className="space-y-4">
                <textarea
                  rows="4"
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Tell us what you like or what we can fix..."
                  className="w-full bg-[#090b0e] border border-slate-800 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500 transition resize-none"
                  required
                ></textarea>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowFeedbackModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg transition"
                  >
                    Submit Feedback
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}